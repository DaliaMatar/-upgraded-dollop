package e.hoda.digi_smartclock;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    TextView location;
    EditText country;
    EditText city;
    //Switch tempSwitch;
    TextView alarmView;
    EditText alarmText;
    //Switch alarmSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        location = (TextView) findViewById(R.id.location);
        country = (EditText) findViewById(R.id.country);
        city = (EditText) findViewById(R.id.city);
        alarmView = (TextView) findViewById(R.id.alarmView);
        alarmText = (EditText) findViewById(R.id.alarmText);


        Switch tempSwitch = (Switch) findViewById(R.id.tempSwitch);
        tempSwitch.setOnClickListener(new View.OnClickListener() {

           
            @Override
            public void onClick(View view) {

            }
        });



        Switch alarmSwitch = (Switch) findViewById(R.id.alarmSwitch);
        alarmSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }
}
